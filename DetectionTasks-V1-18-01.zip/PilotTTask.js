// initialize everything, web server, socket.io, filesystem, johnny-five
var app = require('http').createServer(handler)
  , io = require('socket.io').listen(app)
  , fs = require('fs')
  , WebSocket = require('ws')
  , five = require("johnny-five")
  , hapticboard,led,motor,sensor;
hapticboard = new five.Board();

// on board ready
hapticboard.on("ready", function() {
  // init two motors, on pin 9 and 11, with setting
  motorA = new five.Motor(9);
  //motorA.start(255);
  motorB = new five.Motor(11);
  //motorB.start(255);
});

// make web server listen on port 80
app.listen(80);

// handle web server
function handler (req, res) {
	var url = req.url;
	if (url === "/")
	{
		url = "/Tactile-Task-Setting.html"
	}
  fs.readFile(__dirname + url, function (err, data) {
    if (err) {
      res.writeHead(500);
      return res.end('Error loading ' + url);
    }
    res.writeHead(200);
    res.end(data);
  });
 }

// on a socket connection
io.sockets.on('connection', function (socket) {
  // control motor A
  socket.on('motorA', function (data) {
	 console.log('motor A');
     if(hapticboard.isReady){
		motorA.start(data.start);
		setTimeout(function() {
			motorA.stop();
			}, 50);
	 }
  });
  // control motor B
  socket.on('motorB', function (data) {
	 console.log('motor B');
     if(hapticboard.isReady){
		motorB.start(data.start);
		setTimeout(function() {
			motorB.stop();
			}, 50);
	 }
  });
  // control motor A and motor B
  socket.on('bothmotors', function (data) {
	 console.log('both motors');
     if(hapticboard.isReady){
		motorA.start(data.start);
		motorB.start(data.start);
		setTimeout(function() {
			motorA.stop();
			motorB.stop();
			}, 50);
	 }
  });
});

